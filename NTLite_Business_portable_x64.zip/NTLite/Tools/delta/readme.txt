Explanation of the UpdateCompression.dll library

It is used for Delta file extraction, found in the latest Windows update packages.

UpdateCompression.dll potentially located here is not distributed with the tool, it is automatically extracted and populated from Windows cumulative updates.
It will auto-update to the newest version found. Set the file as read-only to disable auto-updating.

Copy or overwrite your own to \Tools\Delta\x64\ (for 64-bit) or \Tools\Delta\ (32-bit)
See parallel library directories for examples.